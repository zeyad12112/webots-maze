from controller import Robot, DistanceSensor, Motor

#-------------------------------------------------------
# INITIALIZE VARIABLES

TIME_STEP = 64
MAX_SPEED = 6.28

# CREATE THE ROBOT INSTANCE.
robot = Robot()

# GET THE TIME STEP OF THE CURRENT WORLD.
timestep = int(robot.getBasicTimeStep())  # [MS]

# STATES
STATES = ['FORWARD', 'TURN_RIGHT', 'TURN_LEFT']
current_state = STATES[0]

# COUNTER: USED TO MAINTAIN AN ACTIVE STATE FOR A NUMBER OF CYCLES
counter = 0
counter_max = 5

#-------------------------------------------------------
# INITIALIZE DEVICES

# DISTANCE SENSORS
ps = []
ps_names = ['ps0', 'ps1', 'ps2', 'ps3', 'ps4', 'ps5', 'ps6', 'ps7']
for i in range(8):
    ps.append(robot.getDevice(ps_names[i]))
    ps[i].enable(timestep)

# GROUND SENSORS
gs = []
gs_names = ['gs0', 'gs1', 'gs2']
for i in range(3):
    gs.append(robot.getDevice(gs_names[i]))
    gs[i].enable(timestep)

# MOTORS    
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

#-------------------------------------------------------
# MAIN LOOP:
# - PERFORM SIMULATION STEPS UNTIL WEBOTS IS STOPPING THE CONTROLLER
while robot.step(timestep) != -1:
    # UPDATE SENSOR READINGS
    ps_values = []
    for i in range(8):
        ps_values.append(ps[i].getValue())

    gs_values = []
    for i in range(3):
        gs_values.append(gs[i].getValue())

    # PROCESS SENSOR DATA
    line_right = gs_values[0] > 600
    line_left = gs_values[2] > 600
    
    # IMPLEMENT THE LINE-FOLLOWING STATE MACHINE
    if current_state == 'FORWARD':
        # ACTION FOR THE CURRENT STATE: UPDATE SPEED VARIABLES
        left_speed = MAX_SPEED
        right_speed = MAX_SPEED

        # CHECK IF IT IS NECESSARY TO UPDATE CURRENT_STATE
        if line_right and not line_left:
            current_state = 'TURN_RIGHT'
            counter = 0
        elif line_left and not line_right:
            current_state = 'TURN_LEFT'
            counter = 0

    elif current_state == 'TURN_RIGHT':
        # ACTION FOR THE CURRENT STATE: UPDATE SPEED VARIABLES
        left_speed = 0.8 * MAX_SPEED
        right_speed = 0.4 * MAX_SPEED

        # CHECK IF IT IS NECESSARY TO UPDATE CURRENT_STATE
        if counter == counter_max:
            current_state = 'FORWARD'

    elif current_state == 'TURN_LEFT':
        # ACTION FOR THE CURRENT STATE: UPDATE SPEED VARIABLES
        left_speed = 0.4 * MAX_SPEED
        right_speed = 0.8 * MAX_SPEED

        # CHECK IF IT IS NECESSARY TO UPDATE CURRENT_STATE
        if counter == counter_max:
            current_state = 'FORWARD'        

    # INCREMENT COUNTER
    counter += 1

    # PRINT DEBUG INFO
    print('COUNTER: '+ str(counter) + '. CURRENT STATE: ' + current_state)

    # SET MOTOR SPEEDS WITH THE VALUES DEFINED BY THE STATE-MACHINE
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)

    # REPEAT ALL STEPS WHILE THE SIMULATION IS RUNNING.