from controller import Robot, DistanceSensor, Motor
import numpy as np

# -------------------------------------------------------
# Initialize variables
MAX_SPEED = 6.28

# Create the Robot instance
robot = Robot()

# Time step of the simulation [ms]
timestep = int(robot.getBasicTimeStep())
delta_t = timestep / 1000.0  # [s]

# State machine
states = ['forward', 'turn_right', 'turn_left']
current_state = states[0]
counter = 0
COUNTER_MAX = 3

# Robot pose
x = -0.06
y = 0.436
phi = 0.0531

# e-puck physical parameters
R = 0.0205  # wheel radius [m]
D = 0.0565  # distance between wheels [m]

# -------------------------------------------------------
# Initialize devices

# Distance sensors
ps = []
psNames = ['ps0', 'ps1', 'ps2', 'ps3', 'ps4', 'ps5', 'ps6', 'ps7']
for i in range(8):
    ps.append(robot.getDevice(psNames[i]))
    ps[i].enable(timestep)

# Ground sensors
gs = []
gsNames = ['gs0', 'gs1', 'gs2']
for i in range(3):
    gs.append(robot.getDevice(gsNames[i]))
    gs[i].enable(timestep)

# Encoders
encoder = []
encoderNames = ['left wheel sensor', 'right wheel sensor']
for i in range(2):
    encoder.append(robot.getDevice(encoderNames[i]))
    encoder[i].enable(timestep)

oldEncoderValues = []

# Motors
leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

# -------------------------------------------------------
# Robot localization functions

def get_robot_displacement(encoderValues, oldEncoderValues, r, d):
    """Computes linear and angular displacement of the robot"""
    delta_left = encoderValues[0] - oldEncoderValues[0]
    delta_right = encoderValues[1] - oldEncoderValues[1]
    lin_disp = r * (delta_left + delta_right) / 2
    ang_disp = r * (delta_right - delta_left) / d
    return lin_disp, ang_disp

def get_robot_pose2(lin_disp, ang_disp, x_old, y_old, phi_old):
    """Updates robot pose based on heading and displacement"""
    phi_new = phi_old + ang_disp
    x_new = x_old + lin_disp * np.cos(phi_new)
    y_new = y_old + lin_disp * np.sin(phi_new)
    return x_new, y_new, phi_new

# -------------------------------------------------------
# Main loop
while robot.step(timestep) != -1:
    # Read sensors
    psValues = [ps[i].getValue() for i in range(8)]
    gsValues = [gs[i].getValue() for i in range(3)]
    encoderValues = [encoder[i].getValue() for i in range(2)]

    # Initialize old encoder values
    if len(oldEncoderValues) < 2:
        oldEncoderValues = encoderValues.copy()

    # Line-following sensors
    line_right = gsValues[0] > 600
    line_left = gsValues[2] > 600

    # --- State machine ---
    if current_state == 'forward':
        leftSpeed = MAX_SPEED
        rightSpeed = MAX_SPEED
        if line_right and not line_left:
            current_state = 'turn_right'
            counter = 0
        elif line_left and not line_right:
            current_state = 'turn_left'
            counter = 0

    elif current_state == 'turn_right':
        leftSpeed = 0.8 * MAX_SPEED
        rightSpeed = 0.4 * MAX_SPEED
        if counter == COUNTER_MAX:
            current_state = 'forward'

    elif current_state == 'turn_left':
        leftSpeed = 0.4 * MAX_SPEED
        rightSpeed = 0.8 * MAX_SPEED
        if counter == COUNTER_MAX:
            current_state = 'forward'

    counter += 1

    # --- Robot localization using displacement ---
    lin_disp, ang_disp = get_robot_displacement(encoderValues, oldEncoderValues, R, D)
    x, y, phi = get_robot_pose2(lin_disp, ang_disp, x, y, phi)

    # Update old encoder values
    oldEncoderValues = encoderValues.copy()

    # Debug info
    print(f'Sim time: {robot.getTime():.3f}  Pose: x={x:.2f} m, y={y:.2f} m, phi={phi:.4f} rad. State: {current_state}')

    # Set motor speeds
    leftMotor.setVelocity(leftSpeed)
    rightMotor.setVelocity(rightSpeed)