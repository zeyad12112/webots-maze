from controller import Robot, DistanceSensor, Motor
import numpy as np
import math

# -------------------------------------------------------
# Initialize variables

# maximum motor speed (in rad/s).
MAX_SPEED = 6.28  

# Controller gains for wall-following
kd = 0.003
kd2 = 0.003
d_desired = 200 # in units of the proximity sensor


Kp = 0.9  # Proportional gain for PID controller
Ki = 0.01 # Integral gain for PID controller
Kd = 0.01  # Derivative gain for PID controller

# Robot wheel speeds: initial values are zero
wl = 0.0    # angular speed of the left wheel [rad/s]
wr = 0.0    # angular speed of the right wheel [rad/s]


# Robot linear and angular speeds
u = 0.0    # linear speed [m/s]
w = 0.0    # angular speed [rad/s]


# Physical robot dimensions
R = 0.0205  # Wheel radius
D = 0.0565  # Distance between wheels

# Goal position
goal_positions = [(1.98, 0.0),(1.38, 0.0)]
current_goal_index = 0

# Initial robot pose (x, y, heading angle phi)
x = -1.5
y = 0.02
phi = 0.0531

# State machine
states = ['turn_left_initial', 'move_forward', 'turn_right', 'follow_wall', 'turn_-90', 'curve_+90', 'go_to_goal']
current_state = 'move_forward'
counter = 0
COUNTER_MAX = 100

COUNTER_GOAL = 800

#to improve velocity of ud and wd
MAX_LINEAR_SPEED = 0.05
MAX_ANGULAR_SPEED = 1.5

# -------------------------------------------------------
# Initialization

robot = Robot()
timestep = int(robot.getBasicTimeStep())
delta_t = timestep / 1000.0

# distance sensors
ps = [robot.getDevice(f'ps{i}') for i in range(8)]
for sensor in ps:
    sensor.enable(timestep)

# encoders
# Retrieves wheel encoders to track wheel movement.
encoder = [robot.getDevice(name) for name in ['left wheel sensor', 'right wheel sensor']]
for e in encoder:
    e.enable(timestep)
    
# Stores previous encoder readings for speed calculation.
oldEncoderValues = [0.0, 0.0]

# Motors
leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

############################################################################
# Functions

def get_wheels_speed(encoderValues, oldEncoderValues, delta_t):
    """Computes speed of the wheels based on encoder readings"""
    wl = (encoderValues[0] - oldEncoderValues[0]) / delta_t
    wr = (encoderValues[1] - oldEncoderValues[1]) / delta_t
    return wl, wr


def get_robot_speeds(wl, wr, r, d):
    """Computes robot linear and angular speeds"""
    u = (r / 2) * (wl + wr)
    w = (r / d) * (wr - wl)
    return u, w


def get_robot_pose(u, w, x_old, y_old, phi_old, delta_t):
    phi_new = phi_old + w * delta_t
    x_new = x_old + u * delta_t * np.cos(phi_new)
    y_new = y_old + u * delta_t * np.sin(phi_new)
    return x_new, y_new, phi_new

def follow_wall_to_right(kd, kd2, d_r, d_fr, d_desired):
    error = d_r - d_desired
    correction = kd * error + kd2 * (d_fr - d_r)
    u_ref = MAX_LINEAR_SPEED
    w_ref = correction
    return u_ref, w_ref

def wheel_speed_commands(u_d, w_d, D, R):
    wr_d = (2 * u_d + w_d * D) / (2 * R)
    wl_d = (2 * u_d - w_d * D) / (2 * R)

    return wl_d, wr_d

# Robot Localization functions
def pid_controller(phi, x, y, goal_x, goal_y, previous_error, integral_error, delta_t):
    phi_d = np.arctan2(goal_y - y, goal_x - x)
    phi_err = phi_d - phi
    phi_err_correct = np.arctan2(np.sin(phi_err), np.cos(phi_err))
    distance_error = np.sqrt((goal_x - x) ** 2 + (goal_y - y) ** 2)

    print(f"Goal: ({goal_x}, {goal_y}), Position: ({x}, {y})")
    print(f"phi_d: {phi_d}, phi_err: {phi_err}, phi_err_correct: {phi_err_correct}")
    print(f"Distance to goal: {distance_error}")

    integral_error += distance_error * delta_t
    derivative_error = (distance_error - previous_error) / delta_t
    angular_output = Kp * phi_err_correct + Ki * integral_error + Kd * derivative_error
    linear_output = Kp * distance_error

    if np.isnan(linear_output) or np.isnan(angular_output):
        print("Warning: PID controller returned NaN for linear or angular output!")
        linear_output = 0.0
        angular_output = 0.0

    return linear_output, angular_output, distance_error, integral_error

# -------------------------------------------------------
# Main Loop

previous_error = 0
integral_error = 0
goal_x, goal_y = goal_positions[current_goal_index]

while robot.step(timestep) != -1:

    # Sensor readings
    psValues = [sensor.getValue() for sensor in ps]
    encoderValues = [e.getValue() for e in encoder]

    if len(oldEncoderValues) < 2:
        oldEncoderValues = encoderValues[:]

    wl, wr = get_wheels_speed(encoderValues, oldEncoderValues, delta_t)
    u, w = get_robot_speeds(wl, wr, R, D)
    x, y, phi = get_robot_pose(u, w, x, y, phi, delta_t)

    # State Machine
    if current_state == 'turn_left_initial':
        u_d, w_d = 0.0, 0.5
        if counter >= COUNTER_MAX:
            current_state, counter = 'follow_wall', 0

    elif current_state == 'move_forward':
        u_d, w_d = 0.05, 0.0
        if psValues[0] > 150 or psValues[7] > 170:
            current_state, counter = 'turn_left_initial', 0

    elif current_state == 'turn_right':
        u_d, w_d = 0.0, -0.5
        if counter >= COUNTER_MAX:
            current_state, counter = 'follow_wall', 0

    elif current_state == 'follow_wall':
        u_d, w_d = follow_wall_to_right(kd, kd2, psValues[2], psValues[1], d_desired)

    elif current_state == 'turn_-90':
        u_d, w_d = 0.0, 0.5

    elif current_state == 'curve_+90':
        u_d, w_d = 0.03, -0.6
    

    # State Transitions
    if current_state == 'follow_wall':
        if psValues[1] < 80 and psValues[2] < 80:
            current_state, counter = 'curve_+90', 20
        elif psValues[0] > 150 or psValues[7] > 170:
            current_state, counter = 'turn_-90', 0
        elif counter >= COUNTER_GOAL:
            current_state, counter = 'go_to_goal', 0

    elif current_state in ['curve_+90', 'turn_-90'] and counter >= COUNTER_MAX:
        current_state, counter = 'follow_wall', 0
        
    # state go to goal  
    if current_state == 'go_to_goal':
        print(f'Left Speed: {wl:.2f}, Right Speed: {wr:.2f}')
        u_d, w_d, distance_error, integral_error = pid_controller(phi, x, y, goal_x, goal_y, previous_error, integral_error, delta_t)
        if distance_error < 0.05:
            print(f"Reached goal {goal_x}, {goal_y}: Position ({x:.2f}, {y:.2f})")
            leftMotor.setVelocity(0.0)
            rightMotor.setVelocity(0.0)
            current_goal_index += 1
            if current_goal_index >= len(goal_positions):
                break
            goal_x, goal_y = goal_positions[current_goal_index]
            previous_error = 0.0
            integral_error = 0.0
            current_state = 'go_to_goal'
        previous_error = distance_error

    # improve velocity 
    u_d = max(-MAX_LINEAR_SPEED, min(MAX_LINEAR_SPEED, u_d))
    w_d = max(-MAX_ANGULAR_SPEED, min(MAX_ANGULAR_SPEED, w_d))

    # Set motor speeds
    leftSpeed, rightSpeed = wheel_speed_commands(u_d, w_d, D, R)
    leftMotor.setVelocity(leftSpeed)
    rightMotor.setVelocity(rightSpeed)

    print(f'Sim time: {robot.getTime():.3f}  Pose: x={x:.2f} m, y={y:.2f} m, phi={phi:.4f} rad.')
    print(f'Current state = {current_state}, ps = {psValues[2]:.2f}, {psValues[1]:.2f}, {psValues[0]:.2f}, {psValues[7]:.2f}\n')
    
    counter += 1
    oldEncoderValues = encoderValues